# Micro Chaos — Game Design Document
**Version 1.0 | Solo Developer Edition**

---

## 1. Game Overview

**Title:** Micro Chaos
**Genre:** Endless Survival / Platformer
**Platform:** Android (Primary), iOS (Secondary)
**Engine:** Unity 2022 LTS
**Target Audience:** Casual to mid-core players, ages 12+
**Session Length:** 30 seconds – 5 minutes
**Monetization:** Rewarded Ads, Interstitial Ads, Optional IAP

### Elevator Pitch
Micro Chaos is a fast-paced endless survival platformer where the rules of physics and gameplay change every 5 seconds. Players must adapt instantly to survive — controls reverse, gravity flips, the world spins. The chaos is the fun.

### Core Loop
```
Spawn → Survive → Chaos Event Fires → Adapt → Die → Ad / Restart → Survive Longer
```

---

## 2. Core Gameplay

### 2.1 Player Controls

| Action | Mobile Input |
|--------|-------------|
| Move Left | Left side of screen tap/hold |
| Move Right | Right side of screen tap/hold |
| Jump | Swipe up OR dedicated jump button |
| Pause | Top-right corner button |

Controls are context-sensitive and adapt to active chaos events (e.g., reversed controls swap left/right).

### 2.2 Movement Parameters (Base Values)

| Parameter | Value |
|-----------|-------|
| Base Move Speed | 5 units/sec |
| Jump Force | 12 units |
| Gravity Scale | 2.5 |
| Max Fall Speed | -20 units/sec |
| Coyote Time | 0.12 seconds |
| Jump Buffer | 0.15 seconds |

### 2.3 Objective
- Survive as long as possible
- Score = seconds survived × multiplier
- Score multiplier increases every 30 seconds of survival
- No end state — only death

### 2.4 Death Conditions
- Falling off screen (bottom)
- Colliding with obstacle (no health system — one hit kill)
- Screen exits viewport due to camera chaos (fail-safe respawn if player exits bounds)

---

## 3. Chaos Event System

### 3.1 Event Architecture

**Trigger:** Every 5 seconds a new chaos event fires
**Duration:** Events are permanent until replaced (some are temporary with 5-second timers)
**Cooldown:** Same event cannot repeat back-to-back
**Announcement:** 1-second warning animation before event fires ("CHAOS INCOMING!")
**Difficulty Scaling:** After 60 seconds, event pool expands to include harder events

### 3.2 Event Catalogue

#### Tier 1 — Early Game (0–30 seconds)
| ID | Event Name | Description | Duration |
|----|------------|-------------|----------|
| E01 | Speed Boost | Player speed × 2 | Until next event |
| E02 | Slow Motion | Player speed × 0.5 | Until next event |
| E03 | Jump High | Jump force × 1.8 | Until next event |
| E04 | Jump Low | Jump force × 0.5 | Until next event |
| E05 | Fast Obstacles | Obstacle speed × 1.5 | Until next event |

#### Tier 2 — Mid Game (30–60 seconds)
| ID | Event Name | Description | Duration |
|----|------------|-------------|----------|
| E06 | Gravity Flip | Gravity direction inverts | Until next event |
| E07 | Reverse Controls | Left/Right inputs swap | Until next event |
| E08 | Zoom In | Camera zooms to 60% size | Until next event |
| E09 | Zoom Out | Camera zooms to 150% size | Until next event |
| E10 | Dark Mode | Screen dims, limited visibility | 5 seconds |

#### Tier 3 — Late Game (60+ seconds)
| ID | Event Name | Description | Duration |
|----|------------|-------------|----------|
| E11 | Screen Rotate | Camera rotates 90°/180° | Until next event |
| E12 | Ghost Mode | Platforms fade in/out (2s cycle) | Until next event |
| E13 | Tiny Player | Player scale × 0.3 | Until next event |
| E14 | Giant Player | Player scale × 2.5 | Until next event |
| E15 | Chaos Combo | Two random events simultaneously | 8 seconds |

### 3.3 Event Manager Logic (Pseudocode)
```
ChaosManager:
  lastEvent = null
  eventTimer = 5.0
  
  Update():
    eventTimer -= deltaTime
    if eventTimer <= 1.0: ShowWarningUI()
    if eventTimer <= 0:
      newEvent = SelectRandom(availableEvents - lastEvent)
      UndoEvent(lastEvent)
      ApplyEvent(newEvent)
      lastEvent = newEvent
      eventTimer = 5.0
  
  SelectRandom(pool):
    weight events by difficulty tier
    return weighted random pick
```

---

## 4. World Design

### 4.1 Environment

- Infinite scrolling arena (arena-style, not side-scrolling)
- Floating platform layout — procedurally arranged in repeating chunks
- Platform variety: solid, moving, narrow, wide
- Background: single flat color that shifts hue every chaos event
- No decorative elements (performance + minimalism)

### 4.2 Platform System

| Type | Description | Spawn Weight |
|------|-------------|-------------|
| Solid | Static, full-width | 50% |
| Moving | Horizontal slide, 2–4 units/sec | 25% |
| Narrow | Half-width, harder to land on | 15% |
| Disappearing | Fades after player steps on it | 10% (unlocked 30s) |

### 4.3 Obstacle Types

| Type | Behavior |
|------|----------|
| Spike | Static, instant death |
| Bouncer | Pushes player sideways |
| Zapper | Activates/deactivates on timer |
| Projectile | Launched horizontally across screen |

### 4.4 Procedural Generation Rules
- Minimum jump distance always achievable (validated against base jump height)
- Maximum vertical gap ≤ base jump height × 1.2
- Obstacles never block only path at tier 1
- Chunk-based generation: 5 platform chunks pre-generated ahead of player

---

## 5. Scoring System

| Action | Points |
|--------|--------|
| Survive 1 second | +10 pts |
| Survive chaos event | +50 pts bonus |
| Land perfect (center platform) | +5 pts |
| Score multiplier at 30s | ×1.5 |
| Score multiplier at 60s | ×2.0 |
| Score multiplier at 90s | ×3.0 |

**High Score:** Saved locally (PlayerPrefs), cloud save optional in v2.

---

## 6. UI / UX Design

### 6.1 Screen Hierarchy
```
Splash → Main Menu → [Play] → Gameplay → Game Over → Main Menu
                  → [Settings] → Settings Screen
                  → [Leaderboard] → High Score Screen
```

### 6.2 Main Menu
- Game logo (animated, particle burst)
- PLAY button (large, center)
- HIGH SCORE display
- Settings icon (top right)
- Animated background (looping game preview)

### 6.3 Gameplay HUD
- Current Score (top center)
- Timer (top left)
- Chaos Event Countdown bar (bottom)
- "CHAOS!" warning flash (full screen border)
- Pause button (top right)
- Current chaos event name (below score)

### 6.4 Game Over Screen
- "YOU DIED" text with animation
- Final score (large)
- High score (if beaten, animated celebration)
- RESTART button
- MAIN MENU button
- REVIVE with Ad button (1× per session)
- Share Score button

### 6.5 Pause Screen (Modal Overlay)
- Resume button
- Restart button
- Main Menu button
- Music toggle
- SFX toggle

---

## 7. Art Direction

### Visual Style: "Neon Minimal"
- Geometric shapes only — no sprite art required
- Black or deep navy background
- Bright, saturated accent colors for player and platforms
- Player: bright circle or capsule shape
- Platforms: flat rectangles with accent glow
- Obstacles: red/orange geometric shapes
- UI: clean sans-serif, high contrast

### Color Palette
| Element | Color |
|---------|-------|
| Background | #0D0D1A |
| Player | #00F5D4 (cyan) |
| Platform | #7B2FBE (purple) |
| Obstacle | #FF4365 (red) |
| Pickup/Bonus | #FFE900 (yellow) |
| UI Text | #FFFFFF |
| HUD Accent | #00F5D4 |

### Animation Requirements (All CSS/Shader — No Sprites Needed)
- Player squash/stretch on land and jump
- Platform pulse glow (shader or simple scale animation)
- Chaos event flash (camera post-process or UI overlay)
- Death explosion (particle system — circles flying outward)
- Score pop (text punch animation)

---

## 8. Audio Design

### Sound Effects (Free sources: freesound.org, zapsplat.com)
| Event | Sound |
|-------|-------|
| Jump | Short whoosh up |
| Land | Soft thud |
| Death | Descending tone + impact |
| Chaos Event Fire | Electronic zap / whoosh |
| Chaos Warning | Rising beep sequence |
| Score Milestone | Short fanfare chime |
| Button Press | Click |

### Music
- Single looping background track (chiptune/electronic)
- Tempo increases subtly with survival time (pitch shift or BPM parameter)
- Music source: Kevin MacLeod (free) or Incompetech

---

## 9. Monetization

### 9.1 Rewarded Ads
- Trigger: Game Over screen
- Offer: "Continue from death (1× per session)"
- Player gets: 5-second grace period after death
- Implementation: Unity Ads or AdMob rewarded video

### 9.2 Interstitial Ads
- Trigger: Every 3rd death
- Timing: After game over animation, before restart
- Skippable: After 5 seconds
- Do NOT show mid-run (kills retention)

### 9.3 Optional IAP (v2 — Post-MVP)
| Product | Price | Benefit |
|---------|-------|---------|
| Remove Ads | $1.99 | No interstitials |
| Chaos Starter Pack | $0.99 | Unlock skins |
| Double XP | $0.99 | 2× score multiplier |

### 9.4 Ad SDK Integration Points
```csharp
// AdManager.cs — Singleton
public class AdManager : MonoBehaviour {
    public void ShowInterstitial() { /* SDK call */ }
    public void ShowRewarded(Action<bool> callback) { /* SDK call */ }
    public bool IsAdReady() { /* SDK call */ return true; }
}
```

---

## 10. Unity Project Architecture

### 10.1 Folder Structure
```
Assets/
├── _Game/
│   ├── Scripts/
│   │   ├── Core/
│   │   │   ├── GameManager.cs
│   │   │   ├── ScoreManager.cs
│   │   │   └── AudioManager.cs
│   │   ├── Chaos/
│   │   │   ├── ChaosManager.cs
│   │   │   ├── ChaosEvent.cs
│   │   │   └── Events/
│   │   │       ├── GravityFlipEvent.cs
│   │   │       ├── ReverseControlsEvent.cs
│   │   │       ├── SpeedChangeEvent.cs
│   │   │       ├── CameraZoomEvent.cs
│   │   │       ├── ScreenRotateEvent.cs
│   │   │       ├── PlayerSizeEvent.cs
│   │   │       └── PlatformDisappearEvent.cs
│   │   ├── Player/
│   │   │   ├── PlayerController.cs
│   │   │   ├── PlayerPhysics.cs
│   │   │   └── PlayerInput.cs
│   │   ├── World/
│   │   │   ├── PlatformSpawner.cs
│   │   │   ├── PlatformChunk.cs
│   │   │   ├── ObstacleController.cs
│   │   │   └── BackgroundManager.cs
│   │   ├── UI/
│   │   │   ├── MainMenuUI.cs
│   │   │   ├── GameHUD.cs
│   │   │   ├── GameOverUI.cs
│   │   │   ├── PauseMenuUI.cs
│   │   │   └── ChaosEventUI.cs
│   │   ├── Ads/
│   │   │   └── AdManager.cs
│   │   └── Utils/
│   │       ├── ObjectPool.cs
│   │       └── SaveSystem.cs
│   ├── Scenes/
│   │   ├── MainMenu.unity
│   │   └── Game.unity
│   ├── Prefabs/
│   │   ├── Player.prefab
│   │   ├── Platforms/
│   │   │   ├── PlatformSolid.prefab
│   │   │   ├── PlatformMoving.prefab
│   │   │   └── PlatformNarrow.prefab
│   │   ├── Obstacles/
│   │   │   ├── Spike.prefab
│   │   │   ├── Zapper.prefab
│   │   │   └── Projectile.prefab
│   │   └── UI/
│   │       └── ChaosBanner.prefab
│   ├── Materials/
│   │   ├── PlayerMat.mat
│   │   ├── PlatformMat.mat
│   │   └── ObstacleMat.mat
│   ├── Audio/
│   │   ├── SFX/
│   │   └── Music/
│   └── Fonts/
└── Plugins/
    └── Ads/
```

### 10.2 Scene Hierarchy — Game Scene
```
Game Scene
├── [Managers]
│   ├── GameManager
│   ├── ChaosManager
│   ├── ScoreManager
│   ├── AudioManager
│   ├── AdManager
│   └── ObjectPoolManager
├── [World]
│   ├── PlatformSpawner
│   ├── BackgroundQuad
│   └── CameraRig
│       └── Main Camera
├── [Player]
│   └── Player (Rigidbody2D + PlayerController)
└── [UI]
    ├── GameHUD (Canvas)
    ├── PauseMenu (Canvas, hidden)
    └── GameOverScreen (Canvas, hidden)
```

### 10.3 GameManager State Machine
```
States: MENU → PLAYING → PAUSED → GAMEOVER → MENU
```
```csharp
public enum GameState { Menu, Playing, Paused, GameOver }

public class GameManager : MonoBehaviour {
    public static GameManager Instance;
    public GameState CurrentState { get; private set; }
    public event Action<GameState> OnStateChanged;
    
    public void StartGame() => SetState(GameState.Playing);
    public void PauseGame() => SetState(GameState.Paused);
    public void GameOver() => SetState(GameState.GameOver);
    public void ReturnToMenu() => SetState(GameState.Menu);
    
    void SetState(GameState newState) {
        CurrentState = newState;
        OnStateChanged?.Invoke(newState);
        Time.timeScale = (newState == GameState.Paused) ? 0f : 1f;
    }
}
```

---

## 11. Core C# Scripts

### PlayerController.cs
```csharp
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerController : MonoBehaviour {
    [Header("Movement")]
    public float moveSpeed = 5f;
    public float jumpForce = 12f;
    
    [Header("State Modifiers")]
    public bool controlsReversed = false;
    public float speedMultiplier = 1f;
    public float jumpMultiplier = 1f;
    
    private Rigidbody2D rb;
    private bool isGrounded;
    private float coyoteTimer;
    private float jumpBufferTimer;
    private const float COYOTE_TIME = 0.12f;
    private const float JUMP_BUFFER = 0.15f;
    
    void Start() => rb = GetComponent<Rigidbody2D>();
    
    void Update() {
        HandleCoyoteTime();
        HandleJumpBuffer();
        if (PlayerInput.JumpPressed()) jumpBufferTimer = JUMP_BUFFER;
    }
    
    void FixedUpdate() {
        float input = PlayerInput.GetHorizontal();
        if (controlsReversed) input = -input;
        
        rb.linearVelocity = new Vector2(
            input * moveSpeed * speedMultiplier,
            rb.linearVelocity.y
        );
        
        if (jumpBufferTimer > 0 && coyoteTimer > 0) {
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce * jumpMultiplier);
            jumpBufferTimer = 0;
            coyoteTimer = 0;
        }
        
        jumpBufferTimer -= Time.fixedDeltaTime;
    }
    
    void HandleCoyoteTime() {
        if (isGrounded) coyoteTimer = COYOTE_TIME;
        else coyoteTimer -= Time.deltaTime;
    }
    
    void HandleJumpBuffer() => jumpBufferTimer -= Time.deltaTime;
    
    void OnCollisionEnter2D(Collision2D col) {
        if (col.gameObject.CompareTag("Ground")) isGrounded = true;
    }
    
    void OnCollisionExit2D(Collision2D col) {
        if (col.gameObject.CompareTag("Ground")) isGrounded = false;
    }
    
    void OnTriggerEnter2D(Collider2D col) {
        if (col.CompareTag("Obstacle"))
            GameManager.Instance.GameOver();
    }
}
```

### ChaosManager.cs
```csharp
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class ChaosManager : MonoBehaviour {
    public static ChaosManager Instance;
    
    [SerializeField] private List<ChaosEvent> allEvents;
    [SerializeField] private float chaosInterval = 5f;
    [SerializeField] private float warningDuration = 1f;
    
    private ChaosEvent activeEvent;
    private ChaosEvent lastEvent;
    private float timer;
    private float survivalTime;
    
    public event System.Action<ChaosEvent> OnChaosEventFired;
    public event System.Action OnChaosWarning;
    
    void Awake() => Instance = this;
    
    void Update() {
        if (GameManager.Instance.CurrentState != GameState.Playing) return;
        
        survivalTime += Time.deltaTime;
        timer -= Time.deltaTime;
        
        if (timer <= warningDuration && timer > warningDuration - Time.deltaTime)
            OnChaosWarning?.Invoke();
        
        if (timer <= 0) {
            FireNewEvent();
            timer = chaosInterval;
        }
    }
    
    void FireNewEvent() {
        activeEvent?.Undo();
        
        var available = GetAvailableEvents();
        var pick = available[Random.Range(0, available.Count)];
        
        lastEvent = activeEvent;
        activeEvent = pick;
        activeEvent.Apply();
        
        OnChaosEventFired?.Invoke(activeEvent);
    }
    
    List<ChaosEvent> GetAvailableEvents() {
        int tier = survivalTime < 30f ? 1 : survivalTime < 60f ? 2 : 3;
        return allEvents
            .Where(e => e.tier <= tier && e != lastEvent)
            .ToList();
    }
    
    public void ResetChaos() {
        activeEvent?.Undo();
        activeEvent = null;
        lastEvent = null;
        timer = chaosInterval;
        survivalTime = 0f;
    }
}
```

### ChaosEvent.cs (Base Class)
```csharp
using UnityEngine;

[CreateAssetMenu(fileName = "NewChaosEvent", menuName = "MicroChaos/ChaosEvent")]
public abstract class ChaosEvent : ScriptableObject {
    public string eventName;
    public string description;
    public int tier = 1;
    public Color uiColor = Color.white;
    
    public abstract void Apply();
    public abstract void Undo();
}
```

### GravityFlipEvent.cs
```csharp
public class GravityFlipEvent : ChaosEvent {
    private float originalGravity;
    
    public override void Apply() {
        originalGravity = Physics2D.gravity.y;
        Physics2D.gravity = new Vector2(0, -originalGravity);
    }
    
    public override void Undo() {
        Physics2D.gravity = new Vector2(0, originalGravity);
    }
}
```

### ScoreManager.cs
```csharp
using UnityEngine;

public class ScoreManager : MonoBehaviour {
    public static ScoreManager Instance;
    
    public int CurrentScore { get; private set; }
    public int HighScore { get; private set; }
    public float Multiplier { get; private set; } = 1f;
    
    private float survivalTime;
    
    public event System.Action<int> OnScoreChanged;
    
    void Awake() {
        Instance = this;
        HighScore = PlayerPrefs.GetInt("HighScore", 0);
    }
    
    void Update() {
        if (GameManager.Instance.CurrentState != GameState.Playing) return;
        
        survivalTime += Time.deltaTime;
        
        // Update multiplier
        if (survivalTime >= 90f) Multiplier = 3f;
        else if (survivalTime >= 60f) Multiplier = 2f;
        else if (survivalTime >= 30f) Multiplier = 1.5f;
        
        // Add survival score
        CurrentScore += Mathf.RoundToInt(10 * Multiplier * Time.deltaTime);
        OnScoreChanged?.Invoke(CurrentScore);
    }
    
    public void AddBonus(int amount) {
        CurrentScore += Mathf.RoundToInt(amount * Multiplier);
        OnScoreChanged?.Invoke(CurrentScore);
    }
    
    public void SaveScore() {
        if (CurrentScore > HighScore) {
            HighScore = CurrentScore;
            PlayerPrefs.SetInt("HighScore", HighScore);
        }
    }
    
    public void ResetScore() {
        CurrentScore = 0;
        survivalTime = 0f;
        Multiplier = 1f;
    }
}
```

### AdManager.cs
```csharp
using UnityEngine;
using System;

public class AdManager : MonoBehaviour {
    public static AdManager Instance;
    
    private int deathCount = 0;
    private const int INTERSTITIAL_FREQUENCY = 3;
    private bool hasUsedReviveThisSession = false;
    
    void Awake() => Instance = this;
    
    public void OnPlayerDied() {
        deathCount++;
        if (deathCount % INTERSTITIAL_FREQUENCY == 0)
            ShowInterstitial();
    }
    
    public bool CanShowRevive() => !hasUsedReviveThisSession;
    
    public void ShowReviveAd(Action<bool> onComplete) {
        if (!CanShowRevive()) { onComplete(false); return; }
        // TODO: Replace with actual Unity Ads / AdMob call
        Debug.Log("[AdManager] Showing rewarded ad...");
        // Simulate successful ad for now:
        hasUsedReviveThisSession = true;
        onComplete(true);
    }
    
    public void ShowInterstitial() {
        // TODO: Replace with actual Unity Ads / AdMob call
        Debug.Log("[AdManager] Showing interstitial ad...");
    }
    
    public void ResetSession() => hasUsedReviveThisSession = false;
}
```

### ObjectPool.cs
```csharp
using System.Collections.Generic;
using UnityEngine;

public class ObjectPool : MonoBehaviour {
    public static ObjectPool Instance;
    
    [System.Serializable]
    public class Pool {
        public string tag;
        public GameObject prefab;
        public int size;
    }
    
    public List<Pool> pools;
    private Dictionary<string, Queue<GameObject>> poolDict;
    
    void Awake() {
        Instance = this;
        poolDict = new Dictionary<string, Queue<GameObject>>();
        
        foreach (var pool in pools) {
            var queue = new Queue<GameObject>();
            for (int i = 0; i < pool.size; i++) {
                var obj = Instantiate(pool.prefab);
                obj.SetActive(false);
                queue.Enqueue(obj);
            }
            poolDict[pool.tag] = queue;
        }
    }
    
    public GameObject Spawn(string tag, Vector3 position, Quaternion rotation) {
        if (!poolDict.ContainsKey(tag)) return null;
        var obj = poolDict[tag].Dequeue();
        obj.SetActive(true);
        obj.transform.SetPositionAndRotation(position, rotation);
        poolDict[tag].Enqueue(obj);
        return obj;
    }
}
```

---

## 12. Development Roadmap

### Week 1 — Core Systems (MVP Foundation)
| Day | Task |
|-----|------|
| 1 | Unity project setup, folder structure, Git init |
| 2 | Player controller + physics (move, jump, gravity) |
| 3 | Basic platform spawner + object pooling |
| 4 | Chaos Manager + 5 basic events |
| 5 | Score system + death/restart loop |
| 6–7 | Basic UI: Main Menu, HUD, Game Over |

### Week 2 — Polish & Monetization
| Day | Task |
|-----|------|
| 8 | Add 5 more chaos events (tier 2) |
| 9 | Audio system + SFX + music |
| 10 | Visual polish: particles, animations, color shifts |
| 11 | Ad integration (Unity Ads placeholder) |
| 12 | Performance profiling, mobile optimization |
| 13 | Bug fixing + edge cases (bounds, chaos conflicts) |
| 14 | Build APK + test on device |

### Post-MVP (v1.1+)
- Tier 3 chaos events
- Leaderboard (Google Play Games)
- Cloud save
- Daily challenges
- Cosmetic skins (IAP)
- Haptic feedback

---

## 13. Technical Specifications

### Performance Targets
| Metric | Target |
|--------|--------|
| Frame Rate | 60 FPS (all target devices) |
| Memory Usage | < 150 MB RAM |
| APK Size | < 50 MB |
| Load Time | < 3 seconds |

### Minimum Device Spec
- Android 7.0 (API 24)
- 2 GB RAM
- Snapdragon 625 equivalent

### Unity Settings
- Render Pipeline: URP (Universal Render Pipeline)
- Physics: 2D Physics, Fixed timestep 0.02s
- Texture Compression: ASTC
- IL2CPP Scripting Backend
- Strip Engine Code: Enabled

### Mobile Optimization Checklist
- [ ] Object pooling for all spawnable objects
- [ ] No per-frame allocations (watch for string concatenation)
- [ ] Sprite atlas for all UI elements
- [ ] Audio: compressed, mono for SFX
- [ ] Camera: no post-processing on low-end path
- [ ] Physics layers: only necessary collision pairs
- [ ] Disable shadows (2D game — not needed)

---

## 14. Risk Assessment

| Risk | Likelihood | Mitigation |
|------|------------|------------|
| Chaos events feel unfair | Medium | Add 1-second grace period after event fires |
| Performance drops on low-end devices | Low | Object pooling + URP |
| Ad SDK integration delays | Medium | Use placeholders, integrate in week 2 |
| Controls feel slippery | Medium | Tune coyote time + jump buffer early |
| Chaos events conflict (e.g. gravity + rotate) | Medium | Build conflict matrix, prevent combinations |

---

*Document Version: 1.0*
*Last Updated: 2026*
*Author: Solo Developer Build — Micro Chaos*
